"use strict";
exports.id = 107;
exports.ids = [107];
exports.modules = {

/***/ 107:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const reasons = [
    {
        image: "/icons/why-choose-us/expert.png",
        title: "Expert Technical Skills",
        description: "Our technical experts will get you honest, reliable and professional help."
    },
    {
        image: "/icons/why-choose-us/friendly.png",
        title: "Quality assurance",
        description: "We implement strict quality control processes to ensure that all repairs and services are carried out to the highest standards."
    },
    {
        image: "/icons/why-choose-us/diagnosis.png",
        title: "Affordable Diagnosis",
        description: "We will diagnose your issues, provide you with options and give you a price for FREE."
    },
    {
        image: "/icons/why-choose-us/trustworthy.png",
        title: "Trustworthy",
        description: "Our business has been built on trust and customer satisfaction."
    }, 
];
const WhyChooseUs = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "p-6 py-10 md:px-8 md:py-12 lg:px-16 lg:py-16",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "common-style-2 text-center space-y-2",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: "text-2xl md:text-3xl font-semibold text-gray-800",
                    children: "Why Choose Us?"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "max-w-lg mx-auto text-sm md:text-base text-gray-700",
                    children: "We provide you the best computer services and IT Support throughout Bharatpur, Chitwan."
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "grid sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 pt-6 gap-10 md:gap-8 lg:gap-10",
                    children: reasons.map((reason, index)=>{
                        const { image , title , description  } = reason;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "space-y-1",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "inline-block h-20 mx-auto",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: image,
                                        alt: title,
                                        className: "h-full"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "truncate font-medium text-gray-800 uppercase text-lg md:text-base",
                                    children: title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-sm md:text-xs lg:text-sm text-gray-500 px-2",
                                    children: description
                                })
                            ]
                        }, index);
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WhyChooseUs);


/***/ })

};
;