"use strict";
exports.id = 736;
exports.ids = [736];
exports.modules = {

/***/ 9942:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const ButtonAnimation = ({ link , label , color , size , classes =""  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: link,
        passHref: true,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
            className: `animate-button text-white cursor-pointer ${classes !== "" ? classes : "inline-block"} ${color === "red" ? "bg-primary" : "bg-secondary"}`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `text ${size === "small" ? "px-5 py-2" : "px-8 py-4"}`,
                    children: label
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `left-side ${color === "red" ? "bg-primary2" : "bg-secondary2"}`
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `right-side ${color === "red" ? "bg-primary2" : "bg-secondary2"}`
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonAnimation);


/***/ }),

/***/ 9736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Navigation_Navigation)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Static/options.js
const navigationOptions = [
    {
        label: "Services",
        url: "/services"
    },
    {
        label: "IT Support",
        url: "/it-support"
    },
    {
        label: "About Us",
        url: "/about-us"
    },
    {
        label: "Contact",
        url: "/contact"
    }, 
];

// EXTERNAL MODULE: ./components/Common/NavLogo.jsx
var NavLogo = __webpack_require__(5809);
// EXTERNAL MODULE: ./components/Common/Button/ButtonAnimation.jsx
var ButtonAnimation = __webpack_require__(9942);
;// CONCATENATED MODULE: ./components/Static/Sidebar/Sidebar.jsx






const Sidebar = ({ toggled , changeToggled , active  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `fixed top-0 left-0 w-full h-screen bg-black transition-all duration-500 ${toggled ? "z-50 bg-opacity-40" : "-z-10 bg-opacity-0"}`,
                onClick: ()=>changeToggled(false)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `fixed top-0 left-0 bg-red-400 h-screen z-50 transition-all duration-500 overflow-hidden ${toggled ? "w-64" : "w-0"}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "absolute bg-white h-full top-0 w-64 py-8 space-y-6 flex flex-col justify-between",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "space-y-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "px-10",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(NavLogo/* default */.Z, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex flex-col border-t",
                                    children: navigationOptions.map((option, index)=>{
                                        const { label , url  } = option;
                                        return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: url,
                                            passHref: true,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: `py-3 px-10 hover:text-primary transition-all duration-300 border-b border-gray-200 ${active === label ? "text-primary" : ""}`,
                                                children: label
                                            })
                                        }, index);
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "px-6 pb-12 w-full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ButtonAnimation/* default */.Z, {
                                link: "/services",
                                label: "Need Service?",
                                color: "red",
                                classes: "w-full text-center block",
                                handleClick: ()=>window.scrollTo(0, 0)
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Sidebar_Sidebar = (Sidebar);

;// CONCATENATED MODULE: ./components/Common/HamburgerMenu.jsx

const HamburgerMenu = ({ toggled , changeToggled  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "space-y-1 cursor-pointer hamburger-menu relative z-50",
        onClick: ()=>changeToggled(!toggled),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: toggled ? "rotate-45" : ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: toggled ? "rotate-315" : ""
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: toggled ? "fade" : ""
            })
        ]
    });
};
/* harmony default export */ const Common_HamburgerMenu = (HamburgerMenu);

;// CONCATENATED MODULE: ./components/Static/Navigation/Navigation.jsx








const Navigation = ({ active  })=>{
    const { 0: toggled , 1: setToggled  } = (0,external_react_.useState)(false);
    const changeToggled = (bool)=>{
        setToggled(bool);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-white px-6 pt-2 md:px-10 lg:px-16 xl:px-20 border-b border-gray-300 text-gray-600",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "common-style-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-end text-xs text-gray-600 space-x-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "font-semibold border-r border-gray-400 pr-2",
                                    children: "Support"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/contact",
                                            children: "Contact:"
                                        }),
                                        " ",
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "tel:+9779845755635",
                                            children: "+977 9845755635"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "py-4 flex items-center justify-between sticky top-0",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center md:space-x-10 lg:space-x-32",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(NavLogo/* default */.Z, {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "hidden md:flex md:space-x-6 lg:space-x-8 text-sm font-medium text-gray-700",
                                            children: navigationOptions.map((option, index)=>{
                                                const { label , url  } = option;
                                                return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: url,
                                                    passHref: true,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: `hover:text-primary transition-all duration-300 ${active === label ? "text-primary" : ""}`,
                                                        children: label
                                                    })
                                                }, index);
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "md:hidden",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Common_HamburgerMenu, {
                                        toggled: toggled,
                                        changeToggled: changeToggled
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hidden md:flex items-center space-x-4 lg:space-x-10",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ButtonAnimation/* default */.Z, {
                                        link: "/services",
                                        label: "Need Service?",
                                        size: "small",
                                        color: "red",
                                        handleClick: ()=>window.scrollTo(0, 0)
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_Sidebar, {
                    toggled: toggled,
                    changeToggled: changeToggled,
                    active: active
                })
            })
        ]
    });
};
/* harmony default export */ const Navigation_Navigation = (Navigation);


/***/ })

};
;