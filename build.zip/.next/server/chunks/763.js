"use strict";
exports.id = 763;
exports.ids = [763];
exports.modules = {

/***/ 3763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Card_ServiceCard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Common/Button/CardLinkButton.jsx


const CardLinkButton = ({ link , label  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: link,
        passHref: true,
        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
            className: "text-sm text-secondary border px-4 py-2 border-secondary hover:bg-secondary hover:text-white",
            children: label
        })
    });
};
/* harmony default export */ const Button_CardLinkButton = (CardLinkButton);

;// CONCATENATED MODULE: ./components/Common/Card/ServiceCard.jsx


const ServiceCard = ({ id , image , serviceName , shortSummary  })=>{
    const url = `/services/${id}`;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "block border-gray-300 border",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-60 lg:h-72",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: image,
                    loading: "lazy",
                    alt: serviceName,
                    className: "w-full h-full"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-2 pt-3 pb-4 space-y-1.5 text-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "truncate font-medium text-gray-800 uppercase",
                        children: serviceName
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-sm text-gray-500 line-clamp-2 overflow-hidden",
                        children: shortSummary
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex justify-center pt-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button_CardLinkButton, {
                            link: url,
                            label: "Read More"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Card_ServiceCard = (ServiceCard);


/***/ })

};
;