export const navigationOptions = [
  {
    label: "Services",
    url: "/services",
  },
  {
    label: "IT Support",
    url: "/it-support",
  },
  {
    label: "About Us",
    url: "/about-us",
  },
  {
    label: "Contact",
    url: "/contact",
  },
];
