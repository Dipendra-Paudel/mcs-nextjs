import Image from "next/image";

const contactOptions = [
  {
    title: "LOCATION",
    content: "Bharatpur - 10, Chitwan",
    image: "/images/contact/location.png",
  },
  {
    title: "PHONE",
    content: "+977 9845755635",
    image: "/images/contact/call.png",
  },
  {
    title: "EMAIL",
    content: "mistercomputersolutions@gmail.com",
    image: "/images/contact/email.png",
  },
];

const GetInTouch = () => {
  return (
    <div className="common-style">
      <div className="common-style-2 space-y-[30px]">
        <div className="text-center space-y-2">
          <h1 className="text-3xl xl:text-3xl font-extrabold text-gray-800">
            Get In Touch
          </h1>
          <div className="text-sm text-gray-500">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio
            voluptate nobis reiciendis?
          </div>
        </div>
        <div className="grid md:grid-cols-3 gap-[30px]">
          {contactOptions.map((option, index) => {
            const { title, content, image } = option;

            return (
              <div
                className="p-4 text-center bg-gray-100 hover:scale-105 transition-all duration-300"
                key={index}
              >
                <div className="relative w-20 h-20 mx-auto flex items-end justify-center">
                  {index === 1 ? (
                    <div className="w-16 h-16 relative">
                      <Image src={image} alt={title} layout="fill" />
                    </div>
                  ) : (
                    <Image src={image} alt={title} layout="fill" />
                  )}
                </div>
                <div className="text-gray-700 font-semibold pt-4">{title}</div>
                <div className="text-gray-600">{content}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default GetInTouch;
