import Navigation from "../../components/Static/Navigation/Navigation";

const PageNotFound = () => {
  return (
    <div>
      <Navigation active="" />
      <div>Page Not Found</div>
    </div>
  );
};

export default PageNotFound;
